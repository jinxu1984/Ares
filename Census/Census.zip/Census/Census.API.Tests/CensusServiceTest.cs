using Census.API.Infrastructure.Pagination;
using Census.API.Model;
using Census.API.Repositories;
using Census.API.Services;
using Moq;
using System.Collections.Generic;
using Xunit;

namespace Census.API.Tests
{
    public class CensusServiceTest
    {

        [Fact]
        public void Get_CensusEntities_IfActualDataIsAvailable()
        {
            
        }
    }
}
