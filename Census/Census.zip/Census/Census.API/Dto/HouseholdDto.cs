﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Census.API.Dto
{
    public class HouseholdDto
    {
        public int State { get; set; }
        public double HouseHolds { get; set; }
    }
}
