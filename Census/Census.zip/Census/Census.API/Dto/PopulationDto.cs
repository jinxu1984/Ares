﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Census.API.Dto
{
    public class PopulationDto
    {
        public int State { get; set; }
        public double Population { get; set; }
    }
}
